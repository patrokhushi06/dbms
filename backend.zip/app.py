"""
Flask application for the Laboratory Equipment Booking & Maintenance System
(DBMS Review 2).

Serves app.html (one folder above this file) and exposes the JSON API that the
page's JavaScript calls. All database access goes through booking_service.py.

Run:
    py app.py
"""
import datetime
import decimal
import os
import traceback

import psycopg2
from flask import Flask, jsonify, request, send_from_directory
from flask.json.provider import DefaultJSONProvider
from werkzeug.exceptions import HTTPException

import booking_service as svc
from db import AppError

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # folder that holds app.html


class JSONProvider(DefaultJSONProvider):
    """ISO dates/times and plain numbers for Decimal (Flask's default turns them into HTTP dates / strings)."""

    @staticmethod
    def default(o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        if isinstance(o, (datetime.datetime, datetime.date, datetime.time)):
            return o.isoformat()
        return DefaultJSONProvider.default(o)


app = Flask(__name__, static_folder=None)
app.json = JSONProvider(app)


@app.errorhandler(AppError)
def handle_app_error(e):
    return jsonify({"error": e.message}), e.status


@app.errorhandler(psycopg2.Error)
def handle_db_error(e):
    # Trigger / CHECK / FK violations carry the rule's own message, e.g.
    # "Booking rejected: equipment 1 already has an approved booking overlapping this time slot."
    msg = (e.diag.message_primary if e.diag and e.diag.message_primary else str(e)).strip()
    status = 409 if isinstance(e, psycopg2.IntegrityError) else 400
    return jsonify({"error": msg}), status


@app.errorhandler(HTTPException)
def handle_http_exception(e):
    return jsonify({"error": e.description}), e.code


@app.errorhandler(Exception)
def handle_unexpected(e):
    traceback.print_exc()
    return jsonify({"error": "Unexpected server error: " + str(e)}), 500


# ---------------------------------------------------------------------------
# Static UI
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(APP_ROOT, "app.html")


@app.route("/favicon.ico")
def favicon():
    return "", 204


def body():
    return request.get_json(force=True, silent=True) or {}


# ---------------------------------------------------------------------------
# Reference data / dashboard / availability
# ---------------------------------------------------------------------------
@app.route("/api/bootstrap")
def api_bootstrap():
    return jsonify(svc.get_bootstrap())


@app.route("/api/dashboard")
def api_dashboard():
    return jsonify(svc.get_dashboard())


@app.route("/api/availability")
def api_availability():
    journey_date = request.args.get("date")
    if not journey_date:
        raise AppError("date is required", 400)
    return jsonify(svc.get_availability(journey_date))


# ---------------------------------------------------------------------------
# Bookings and usage
# ---------------------------------------------------------------------------
@app.route("/api/bookings", methods=["GET", "POST"])
def api_bookings():
    if request.method == "POST":
        return jsonify(svc.create_booking(body())), 201
    return jsonify(svc.list_bookings(request.args.get("status")))


@app.route("/api/bookings/<int:booking_id>/status", methods=["POST"])
def api_booking_status(booking_id):
    return jsonify(svc.set_booking_status(booking_id, body().get("status")))


@app.route("/api/usage", methods=["POST"])
def api_usage():
    return jsonify(svc.log_usage(body())), 201


# ---------------------------------------------------------------------------
# Equipment
# ---------------------------------------------------------------------------
@app.route("/api/equipment", methods=["GET", "POST"])
def api_equipment():
    if request.method == "POST":
        return jsonify(svc.create_equipment(body())), 201
    return jsonify(svc.list_equipment())


@app.route("/api/equipment/<int:equipment_id>/status", methods=["POST"])
def api_equipment_status(equipment_id):
    return jsonify(svc.set_equipment_status(equipment_id, body().get("status")))


# ---------------------------------------------------------------------------
# Calibration, breakdowns, maintenance
# ---------------------------------------------------------------------------
@app.route("/api/calibrations", methods=["POST"])
def api_calibrations():
    return jsonify(svc.create_calibration(body())), 201


@app.route("/api/breakdowns", methods=["POST"])
def api_breakdowns():
    return jsonify(svc.report_breakdown(body())), 201


@app.route("/api/breakdowns/open")
def api_open_breakdowns():
    return jsonify(svc.list_open_breakdowns())


@app.route("/api/maintenance", methods=["GET", "POST"])
def api_maintenance():
    if request.method == "POST":
        return jsonify(svc.create_maintenance(body())), 201
    return jsonify(svc.list_maintenance())


@app.route("/api/maintenance/<int:maintenance_id>/status", methods=["POST"])
def api_maintenance_status(maintenance_id):
    return jsonify(svc.set_maintenance_status(maintenance_id, body()))


# ---------------------------------------------------------------------------
# Consumables
# ---------------------------------------------------------------------------
@app.route("/api/consumables/<int:consumable_id>/<mode>", methods=["POST"])
def api_consumable(consumable_id, mode):
    if mode not in ("use", "restock"):
        raise AppError("mode must be use or restock", 400)
    return jsonify(svc.change_stock(consumable_id, mode, body().get("qty")))


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
@app.route("/api/reports/utilization")
def api_report_utilization():
    return jsonify(svc.report_utilization())


@app.route("/api/reports/calibration")
def api_report_calibration():
    return jsonify(svc.report_calibration())


@app.route("/api/reports/downtime")
def api_report_downtime():
    return jsonify(svc.report_downtime())


@app.route("/api/reports/stock")
def api_report_stock():
    return jsonify(svc.report_stock())


@app.route("/api/reports/audit")
def api_report_audit():
    return jsonify(svc.report_audit())


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
