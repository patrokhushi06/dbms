"""Small connection-pool wrapper around psycopg2."""
from contextlib import contextmanager

import psycopg2.extras
from psycopg2 import pool

import config

_pool = pool.ThreadedConnectionPool(
    minconn=1,
    maxconn=8,
    host=config.DB_HOST,
    port=config.DB_PORT,
    user=config.DB_USER,
    password=config.DB_PASSWORD,
    dbname=config.DB_NAME,
)


@contextmanager
def get_cursor(commit=True):
    """Yields (cnx, cursor). Commits on clean exit, rolls back on exception."""
    cnx = _pool.getconn()
    cur = cnx.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    try:
        yield cnx, cur
        if commit:
            cnx.commit()
        else:
            cnx.rollback()
    except Exception:
        cnx.rollback()
        raise
    finally:
        cur.close()
        _pool.putconn(cnx)


class AppError(Exception):
    """A user-facing error: (http_status, message)."""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status
