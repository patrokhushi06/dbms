"""Database connection settings, read from environment variables only.

No password is ever hardcoded. Set these before running the server
(PowerShell: $env:LAB_DB_PASSWORD = '...'):

  LAB_DB_HOST      default 127.0.0.1
  LAB_DB_PORT      default 5432
  LAB_DB_USER      default postgres
  LAB_DB_PASSWORD  required, no default
  LAB_DB_NAME      default labequipment
"""
import os
import sys

DB_HOST = os.environ.get("LAB_DB_HOST", "127.0.0.1")
DB_PORT = int(os.environ.get("LAB_DB_PORT", "5432"))
DB_USER = os.environ.get("LAB_DB_USER", "postgres")
DB_PASSWORD = os.environ.get("LAB_DB_PASSWORD")
DB_NAME = os.environ.get("LAB_DB_NAME", "labequipment")

if not DB_PASSWORD:
    sys.stderr.write(
        "ERROR: LAB_DB_PASSWORD is not set. Set it in the environment before "
        "starting the server, e.g. (PowerShell): $env:LAB_DB_PASSWORD = 'yourpassword'\n"
    )
    sys.exit(1)
