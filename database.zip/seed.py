"""
Review 3 database setup script.

Drops and recreates the LabEquipment database, runs schema.sql (tables, indexes,
triggers, views) and then populates it with reference data (laboratories,
categories, vendors, users, equipment, time slots, calibration history) plus
sample transactional data (bookings, usage logs, breakdowns, maintenance jobs,
consumables) so the app has something to book against and report on the moment
it starts.

Usage:
    py database/seed.py

Reads connection settings from environment variables (same names as the app):
    LAB_DB_HOST (127.0.0.1)  LAB_DB_PORT (5432)  LAB_DB_USER (postgres)
    LAB_DB_PASSWORD (required)  LAB_DB_NAME (labequipment)
All people, vendors and equipment are fictional.
"""
import os
import sys

import psycopg2
from psycopg2 import sql

HOST = os.environ.get("LAB_DB_HOST", "127.0.0.1")
PORT = int(os.environ.get("LAB_DB_PORT", "5432"))
USER = os.environ.get("LAB_DB_USER", "postgres")
PASSWORD = os.environ.get("LAB_DB_PASSWORD")
DB_NAME = os.environ.get("LAB_DB_NAME", "labequipment")

if not PASSWORD:
    print("ERROR: set LAB_DB_PASSWORD in the environment before running this script.")
    sys.exit(1)

SCHEMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")


def recreate_database():
    cnx = psycopg2.connect(host=HOST, port=PORT, user=USER, password=PASSWORD, dbname="postgres")
    cnx.autocommit = True
    cur = cnx.cursor()
    cur.execute("SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                "WHERE datname = %s AND pid <> pg_backend_pid()", (DB_NAME,))
    cur.execute(sql.SQL("DROP DATABASE IF EXISTS {}").format(sql.Identifier(DB_NAME)))
    cur.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(DB_NAME)))
    cur.close()
    cnx.close()


def run_schema(cnx):
    # psycopg2 sends the whole script (including $$ function bodies) in one go.
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        script = f.read()
    cur = cnx.cursor()
    cur.execute(script)
    cnx.commit()
    cur.close()
    print("Schema created.")


def ins(cur, table, cols, rows):
    """Insert rows one by one so the validation triggers see earlier rows."""
    stmt = "INSERT INTO {} ({}) VALUES ({})".format(table, ", ".join(cols), ", ".join(["%s"] * len(cols)))
    for r in rows:
        cur.execute(stmt, r)


def seed_data(cnx):
    cur = cnx.cursor()

    ins(cur, "Laboratory", ("laboratory_id", "name", "location"), [
        (1, "Physics Laboratory", "Science Block, Floor 1"),
        (2, "Chemistry Laboratory", "Science Block, Floor 2"),
        (3, "Electronics Laboratory", "Engineering Block, Floor 3"),
    ])
    ins(cur, "EquipmentCategory", ("category_id", "name", "description"), [
        (1, "Measurement", "Balances, meters and precision measuring instruments"),
        (2, "Optical", "Microscopes and optical inspection instruments"),
        (3, "Analytical", "Spectroscopy and sample analysis instruments"),
        (4, "Electronic Test", "Oscilloscopes, generators and signal test equipment"),
    ])
    ins(cur, "Vendor", ("vendor_id", "name", "phone", "email"), [
        (1, "Sigma Scientific Services", "9811000101", "support@sigmascientific.example.com"),
        (2, "Precision Calibration Pvt Ltd", "9811000102", "service@precisioncal.example.com"),
        (3, "Orbit Instrument Care", "9811000103", "help@orbitcare.example.com"),
    ])
    ins(cur, "AppUser", ("user_id", "name", "email", "role"), [
        (1, "Dr. Anita Rao", "anita.rao@lab.example.edu", "LAB_STAFF"),
        (2, "Rohan Mehta", "rohan.mehta@lab.example.edu", "STUDENT"),
        (3, "Sneha Kulkarni", "sneha.kulkarni@lab.example.edu", "STUDENT"),
        (4, "Arjun Nair", "arjun.nair@lab.example.edu", "STUDENT"),
        (5, "Prof. Kiran Desai", "kiran.desai@lab.example.edu", "ADMIN"),
    ])
    # Equipment 4 and 5 start ACTIVE; the breakdown/maintenance triggers change their status below
    ins(cur, "Equipment", ("equipment_id", "laboratory_id", "category_id", "name", "serial_no", "purchase_date", "status"), [
        (1, 3, 4, "Digital Oscilloscope", "OSC-2023-0101", "2023-06-12", "ACTIVE"),
        (2, 2, 3, "UV-Vis Spectrophotometer", "SPC-2022-0207", "2022-11-03", "ACTIVE"),
        (3, 2, 1, "Analytical Balance", "BAL-2024-0310", "2024-02-19", "ACTIVE"),
        (4, 1, 2, "Optical Microscope", "MIC-2021-0412", "2021-08-25", "ACTIVE"),
        (5, 2, 1, "Bench pH Meter", "PHM-2022-0518", "2022-04-14", "ACTIVE"),
        (6, 2, 3, "Hot Air Oven (old unit)", "OVN-2015-0621", "2015-01-30", "RETIRED"),
    ])
    ins(cur, "Calibration", ("calibration_id", "equipment_id", "calibration_date", "next_due_date", "performed_by"), [
        (1, 1, "2025-04-10", "2026-04-10", "Precision Calibration Pvt Ltd"),
        (2, 1, "2026-04-10", "2027-04-10", "Precision Calibration Pvt Ltd"),
        (3, 2, "2026-05-01", "2026-11-01", "Sigma Scientific Services"),
        (4, 3, "2026-08-20", "2027-02-20", "Precision Calibration Pvt Ltd"),
        (5, 4, "2026-02-10", "2026-08-10", "Orbit Instrument Care"),
        (6, 5, "2026-01-15", "2026-07-15", "Precision Calibration Pvt Ltd"),
    ])
    ins(cur, "TimeSlot", ("slot_id", "slot_date", "start_time", "end_time"), [
        (1, "2026-10-20", "09:00", "11:00"),
        (2, "2026-10-20", "10:00", "12:00"),   # overlaps slot 1
        (3, "2026-10-20", "11:00", "13:00"),   # touches slot 1 at 11:00 (no overlap)
        (4, "2026-10-21", "14:00", "16:00"),
        (5, "2026-10-14", "09:00", "12:00"),
        (6, "2026-10-15", "10:00", "12:00"),
        (7, "2026-10-12", "13:00", "15:00"),
        (8, "2026-10-22", "09:00", "11:00"),
        (9, "2026-10-20", "14:00", "16:00"),
    ])
    cnx.commit()

    # Bookings: history first, then upcoming; every PENDING/APPROVED row passes trg_validate_booking
    ins(cur, "Booking", ("booking_id", "user_id", "equipment_id", "slot_id", "status", "requested_on", "purpose"), [
        (1, 2, 1, 5, "COMPLETED", "2026-10-10 10:15", "Waveform analysis for signals lab"),
        (2, 3, 2, 6, "COMPLETED", "2026-10-11 09:30", "Absorbance measurement of dye samples"),
        (3, 4, 3, 7, "COMPLETED", "2026-10-08 16:45", "Mass measurement for titration practical"),
        (8, 2, 4, 7, "COMPLETED", "2026-10-09 11:00", "Slide observation for physics practical"),
        (9, 4, 2, 6, "CANCELLED", "2026-10-12 08:20", "Duplicate request for the same slot"),
        (10, 2, 5, 7, "REJECTED", "2026-10-09 12:10", "Buffer pH check (calibration had expired)"),
        (4, 2, 1, 1, "APPROVED", "2026-10-14 09:00", "Filter circuit measurements"),
        (5, 3, 2, 2, "APPROVED", "2026-10-14 09:40", "Kinetics study using UV-Vis"),
        (6, 4, 1, 3, "APPROVED", "2026-10-15 10:05", "Signal generator output testing"),
        (7, 3, 3, 4, "PENDING", "2026-10-15 14:25", "Precision weighing for sample preparation"),
        (11, 3, 1, 8, "APPROVED", "2026-10-15 15:00", "Project demo capture"),
    ])
    ins(cur, "UsageLog", ("usage_log_id", "booking_id", "usage_date", "hours_used", "details"), [
        (1, 1, "2026-10-14", 2.50, "Captured and saved waveforms for three circuits"),
        (2, 2, "2026-10-15", 1.50, "Measured absorbance of five dye dilutions"),
        (3, 3, "2026-10-12", 2.00, "Weighed samples for titration batch"),
        (4, 8, "2026-10-12", 1.00, "Observed prepared slides, stage began to jam"),
    ])
    cnx.commit()

    # Open breakdowns set the equipment status to BROKEN via trigger
    ins(cur, "Breakdown", ("breakdown_id", "equipment_id", "reported_on", "resolved_on", "description", "status"), [
        (1, 1, "2026-08-03", "2026-08-07", "Display flicker caused by power board fault", "RESOLVED"),
        (2, 4, "2026-10-05", None, "Illumination lamp failure and stage jam", "REPORTED"),
        (3, 3, "2026-09-12", "2026-09-14", "Drifting readings from the load cell", "RESOLVED"),
        (4, 5, "2026-10-10", None, "Electrode response very slow, readings unstable", "REPORTED"),
    ])
    # Maintenance status changes update Equipment and Breakdown via trigger
    ins(cur, "MaintenanceJob", ("maintenance_id", "equipment_id", "vendor_id", "breakdown_id", "description",
                                "start_date", "completion_date", "status", "cost"), [
        (1, 1, 1, 1, "Power board replacement", "2026-08-04", "2026-08-07", "COMPLETED", 4200.00),
        (2, 3, 2, 3, "Load cell recalibration and cleaning", "2026-09-13", "2026-09-14", "COMPLETED", 2500.00),
        (3, 4, 3, 2, "Lamp replacement and stage mechanism repair", "2026-10-07", None, "IN_PROGRESS", 0.00),
        (4, 2, 2, None, "Annual preventive maintenance", "2026-11-02", None, "SCHEDULED", 0.00),
    ])
    ins(cur, "Consumable", ("consumable_id", "equipment_id", "item_name", "unit", "stock_quantity", "reorder_level"), [
        (1, 2, "Quartz cuvettes", "pcs", 12, 10),
        (2, 2, "Reference standard solution", "bottles", 3, 5),
        (3, 3, "Weighing paper", "sheets", 0, 50),
        (4, 5, "pH 7 buffer solution", "bottles", 4, 6),
        (5, 1, "Probe tips", "pcs", 20, 8),
        (6, 4, "Lens cleaning tissue", "sheets", 40, 25),
    ])
    cnx.commit()

    # Explicit ids were used above, so move every identity sequence past the loaded rows
    tables = [("Laboratory", "laboratory_id"), ("EquipmentCategory", "category_id"), ("Vendor", "vendor_id"),
              ("AppUser", "user_id"), ("Equipment", "equipment_id"), ("TimeSlot", "slot_id"),
              ("Booking", "booking_id"), ("UsageLog", "usage_log_id"), ("Calibration", "calibration_id"),
              ("Breakdown", "breakdown_id"), ("MaintenanceJob", "maintenance_id"), ("Consumable", "consumable_id")]
    for table, col in tables:
        cur.execute("SELECT setval(pg_get_serial_sequence(%s, %s), (SELECT COALESCE(MAX({c}), 1) FROM {t}))"
                    .format(c=col, t=table), (table.lower(), col))
    cnx.commit()
    cur.close()
    print("Sample data inserted.")


def main():
    recreate_database()
    cnx = psycopg2.connect(host=HOST, port=PORT, user=USER, password=PASSWORD, dbname=DB_NAME)
    run_schema(cnx)
    seed_data(cnx)
    cnx.close()
    print(f"Done. Database '{DB_NAME}' is ready.")


if __name__ == "__main__":
    main()
