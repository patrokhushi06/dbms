"""All database-facing business logic for the Laboratory Equipment Booking &
Maintenance System.

The business rules themselves (no overlapping approved bookings, only ACTIVE
equipment, valid calibration, stock >= 0, maintenance lifecycle) live in the
database as triggers and CHECK constraints. This module runs each operation in a
single transaction and lets the database's own error message reach the UI.
"""
from db import AppError, get_cursor

VALID_NEW_BOOKING = {"PENDING", "APPROVED"}
VALID_BOOKING_STATUS = {"PENDING", "APPROVED", "REJECTED", "CANCELLED", "COMPLETED"}
VALID_EQUIPMENT_STATUS = {"ACTIVE", "UNDER_MAINTENANCE", "BROKEN", "RETIRED"}
VALID_NEW_JOB = {"SCHEDULED", "IN_PROGRESS"}
AUDIT_SQL = "SELECT * FROM vw_BookingAudit"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _rows(cur, sql, params=()):
    cur.execute(sql, params)
    return cur.fetchall() if cur.description else []


def _need(body, *keys):
    for k in keys:
        if body.get(k) in (None, ""):
            raise AppError(f"Missing field: {k}", 400)


# ---------------------------------------------------------------------------
# Reference data (bootstrap) and dashboard
# ---------------------------------------------------------------------------
def get_bootstrap():
    with get_cursor(commit=False) as (_, cur):
        return {
            "labs": _rows(cur, "SELECT laboratory_id AS id, name, location FROM Laboratory ORDER BY 1"),
            "categories": _rows(cur, "SELECT category_id AS id, name FROM EquipmentCategory ORDER BY 1"),
            "vendors": _rows(cur, "SELECT vendor_id AS id, name FROM Vendor ORDER BY 1"),
            "users": _rows(cur, "SELECT user_id AS id, name, role FROM AppUser ORDER BY 1"),
            "slots": _rows(cur, "SELECT slot_id AS id, slot_date, start_time, end_time FROM TimeSlot "
                                "ORDER BY slot_date, start_time"),
            "equipment": _rows(cur, """
                SELECT e.equipment_id AS id, e.name, e.status, e.serial_no,
                       l.name AS laboratory, c.name AS category
                FROM Equipment e
                JOIN Laboratory l ON l.laboratory_id = e.laboratory_id
                JOIN EquipmentCategory c ON c.category_id = e.category_id
                ORDER BY 1"""),
        }


def get_dashboard():
    with get_cursor(commit=False) as (_, cur):
        kpi = _rows(cur, """
            SELECT (SELECT COUNT(*) FROM Equipment WHERE status = 'ACTIVE')            AS active_equipment,
                   (SELECT COUNT(*) FROM Equipment)                                    AS total_equipment,
                   (SELECT COUNT(*) FROM Booking WHERE status = 'PENDING')             AS pending_bookings,
                   (SELECT COUNT(*) FROM Booking WHERE status = 'APPROVED')            AS approved_bookings,
                   (SELECT COUNT(*) FROM Breakdown WHERE status <> 'RESOLVED')         AS open_breakdowns,
                   (SELECT COUNT(*) FROM vw_CalibrationDue
                     WHERE calibration_status = 'OVERDUE')                             AS overdue_calibrations,
                   (SELECT COUNT(*) FROM vw_LowStock WHERE stock_status <> 'OK')       AS low_stock_items""")[0]
        return {
            "kpi": kpi,
            "recent": _rows(cur, AUDIT_SQL + " ORDER BY booking_id DESC LIMIT 6"),
            "utilization": _rows(cur, "SELECT * FROM vw_EquipmentUtilization ORDER BY utilization_pct DESC, equipment_id"),
        }


# ---------------------------------------------------------------------------
# Availability (Report 1)
# ---------------------------------------------------------------------------
def get_availability(journey_date):
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, """
            SELECT e.equipment_id, e.name AS equipment_name, l.name AS laboratory,
                   t.slot_id, t.slot_date, t.start_time, t.end_time,
                   CASE
                     WHEN cal.next_due < t.slot_date THEN 'NOT READY - CALIBRATION OVERDUE'
                     WHEN EXISTS (SELECT 1 FROM Booking b JOIN TimeSlot bt ON bt.slot_id = b.slot_id
                                  WHERE b.equipment_id = e.equipment_id AND b.status = 'APPROVED'
                                    AND bt.slot_date = t.slot_date
                                    AND bt.start_time < t.end_time AND bt.end_time > t.start_time)
                          THEN 'BOOKED'
                     ELSE 'FREE'
                   END AS availability
            FROM Equipment e
            JOIN Laboratory l ON l.laboratory_id = e.laboratory_id
            CROSS JOIN TimeSlot t
            LEFT JOIN LATERAL (SELECT c.next_due_date AS next_due FROM Calibration c
                               WHERE c.equipment_id = e.equipment_id
                               ORDER BY c.calibration_date DESC LIMIT 1) cal ON TRUE
            WHERE e.status = 'ACTIVE' AND t.slot_date = %s
            ORDER BY e.equipment_id, t.start_time""", (journey_date,))


# ---------------------------------------------------------------------------
# Bookings and usage
# ---------------------------------------------------------------------------
def list_bookings(status=None):
    with get_cursor(commit=False) as (_, cur):
        if status:
            return _rows(cur, AUDIT_SQL + " WHERE booking_status = %s ORDER BY slot_date DESC, booking_id DESC", (status,))
        return _rows(cur, AUDIT_SQL + " ORDER BY slot_date DESC, start_time DESC, booking_id DESC")


def create_booking(body):
    _need(body, "userId", "equipmentId", "slotId", "purpose")
    status = body.get("status", "PENDING")
    if status not in VALID_NEW_BOOKING:
        raise AppError("A new booking can only be PENDING or APPROVED", 400)
    with get_cursor() as (_, cur):
        # trg_validate_booking runs here: ACTIVE equipment, calibration, overlap
        cur.execute("INSERT INTO Booking (user_id, equipment_id, slot_id, status, purpose) "
                    "VALUES (%s, %s, %s, %s, %s) RETURNING booking_id",
                    (body["userId"], body["equipmentId"], body["slotId"], status, body["purpose"]))
        bid = cur.fetchone()["booking_id"]
    return {"bookingId": bid, "status": status}


def set_booking_status(booking_id, status):
    if status not in VALID_BOOKING_STATUS:
        raise AppError("Invalid booking status", 400)
    with get_cursor() as (_, cur):
        cur.execute("UPDATE Booking SET status = %s WHERE booking_id = %s", (status, booking_id))
        if cur.rowcount == 0:
            raise AppError("Booking not found", 404)
    return {"ok": True}


def log_usage(body):
    _need(body, "bookingId", "hours", "details")
    with get_cursor() as (_, cur):
        cur.execute("INSERT INTO UsageLog (booking_id, usage_date, hours_used, details) "
                    "SELECT b.booking_id, t.slot_date, %s, %s "
                    "FROM Booking b JOIN TimeSlot t ON t.slot_id = b.slot_id WHERE b.booking_id = %s "
                    "RETURNING usage_log_id", (body["hours"], body["details"], body["bookingId"]))
        row = cur.fetchone()
        if row is None:
            raise AppError("Booking not found", 404)
        uid = row["usage_log_id"]
    return {"usageLogId": uid}


# ---------------------------------------------------------------------------
# Equipment
# ---------------------------------------------------------------------------
def list_equipment():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, """
            SELECT e.equipment_id, e.name, e.serial_no, l.name AS laboratory, c.name AS category,
                   e.purchase_date, e.status
            FROM Equipment e
            JOIN Laboratory l ON l.laboratory_id = e.laboratory_id
            JOIN EquipmentCategory c ON c.category_id = e.category_id
            ORDER BY e.equipment_id""")


def create_equipment(body):
    _need(body, "name", "serialNo", "laboratoryId", "categoryId", "purchaseDate")
    with get_cursor() as (_, cur):
        cur.execute("INSERT INTO Equipment (laboratory_id, category_id, name, serial_no, purchase_date, status) "
                    "VALUES (%s, %s, %s, %s, %s, 'ACTIVE') RETURNING equipment_id",
                    (body["laboratoryId"], body["categoryId"], body["name"], body["serialNo"], body["purchaseDate"]))
        eid = cur.fetchone()["equipment_id"]
    return {"equipmentId": eid}


def set_equipment_status(equipment_id, status):
    if status not in VALID_EQUIPMENT_STATUS:
        raise AppError("Invalid equipment status", 400)
    with get_cursor() as (_, cur):
        cur.execute("UPDATE Equipment SET status = %s WHERE equipment_id = %s", (status, equipment_id))
        if cur.rowcount == 0:
            raise AppError("Equipment not found", 404)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Calibration, breakdowns, maintenance
# ---------------------------------------------------------------------------
def create_calibration(body):
    _need(body, "equipmentId", "calibrationDate", "nextDueDate", "performedBy")
    with get_cursor() as (_, cur):
        cur.execute("INSERT INTO Calibration (equipment_id, calibration_date, next_due_date, performed_by) "
                    "VALUES (%s, %s, %s, %s) RETURNING calibration_id",
                    (body["equipmentId"], body["calibrationDate"], body["nextDueDate"], body["performedBy"]))
        cid = cur.fetchone()["calibration_id"]
    return {"calibrationId": cid}


def report_breakdown(body):
    _need(body, "equipmentId", "description")
    with get_cursor() as (_, cur):
        # trg_breakdown_reported marks ACTIVE equipment as BROKEN
        cur.execute("INSERT INTO Breakdown (equipment_id, reported_on, description, status) "
                    "VALUES (%s, CURRENT_DATE, %s, 'REPORTED') RETURNING breakdown_id",
                    (body["equipmentId"], body["description"]))
        bid = cur.fetchone()["breakdown_id"]
    return {"breakdownId": bid}


def list_open_breakdowns():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, "SELECT bd.breakdown_id AS id, e.name AS equipment_name, bd.description "
                          "FROM Breakdown bd JOIN Equipment e ON e.equipment_id = bd.equipment_id "
                          "WHERE bd.status <> 'RESOLVED' ORDER BY 1")


def list_maintenance():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, """
            SELECT mj.maintenance_id, e.name AS equipment_name, v.name AS vendor_name, mj.breakdown_id,
                   mj.description, mj.start_date, mj.completion_date, mj.status, mj.cost
            FROM MaintenanceJob mj
            JOIN Equipment e ON e.equipment_id = mj.equipment_id
            JOIN Vendor v ON v.vendor_id = mj.vendor_id
            ORDER BY mj.maintenance_id DESC""")


def create_maintenance(body):
    _need(body, "equipmentId", "vendorId", "description")
    status = body.get("status", "IN_PROGRESS")
    if status not in VALID_NEW_JOB:
        raise AppError("A new job can only be SCHEDULED or IN_PROGRESS", 400)
    with get_cursor() as (_, cur):
        # trg_maintenance_lifecycle runs here
        cur.execute("INSERT INTO MaintenanceJob (equipment_id, vendor_id, breakdown_id, description, "
                    "start_date, status, cost) VALUES (%s, %s, %s, %s, COALESCE(%s::date, CURRENT_DATE), %s, 0) "
                    "RETURNING maintenance_id",
                    (body["equipmentId"], body["vendorId"], body.get("breakdownId") or None,
                     body["description"], body.get("startDate") or None, status))
        mid = cur.fetchone()["maintenance_id"]
    return {"maintenanceId": mid}


def set_maintenance_status(maintenance_id, body):
    status = body.get("status")
    with get_cursor() as (_, cur):
        if status == "COMPLETED":
            cur.execute("UPDATE MaintenanceJob SET status = 'COMPLETED', "
                        "completion_date = GREATEST(CURRENT_DATE, start_date), cost = %s WHERE maintenance_id = %s",
                        (body.get("cost") or 0, maintenance_id))
        elif status in ("SCHEDULED", "IN_PROGRESS"):
            cur.execute("UPDATE MaintenanceJob SET status = %s WHERE maintenance_id = %s", (status, maintenance_id))
        else:
            raise AppError("Invalid maintenance status", 400)
        if cur.rowcount == 0:
            raise AppError("Maintenance job not found", 404)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Consumables
# ---------------------------------------------------------------------------
def change_stock(consumable_id, mode, qty):
    try:
        qty = int(qty)
    except (TypeError, ValueError):
        raise AppError("Quantity must be a whole number", 400)
    if qty <= 0:
        raise AppError("Quantity must be positive", 400)
    delta = qty if mode == "restock" else -qty
    with get_cursor() as (_, cur):
        # CHECK (stock_quantity >= 0) rejects any use above the available stock
        cur.execute("UPDATE Consumable SET stock_quantity = stock_quantity + %s WHERE consumable_id = %s",
                    (delta, consumable_id))
        if cur.rowcount == 0:
            raise AppError("Consumable not found", 404)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
def report_utilization():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, "SELECT * FROM vw_EquipmentUtilization ORDER BY utilization_pct DESC, equipment_id")


def report_calibration():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, "SELECT * FROM vw_CalibrationDue ORDER BY days_to_due")


def report_downtime():
    with get_cursor(commit=False) as (_, cur):
        return {
            "detail": _rows(cur, """
                SELECT bd.breakdown_id, e.name AS equipment_name, bd.reported_on, bd.resolved_on,
                       COALESCE(bd.resolved_on, CURRENT_DATE) - bd.reported_on AS downtime_days,
                       bd.status AS breakdown_status, v.name AS vendor_name,
                       mj.status AS maintenance_status, COALESCE(mj.cost, 0) AS maintenance_cost
                FROM Breakdown bd
                JOIN Equipment e ON e.equipment_id = bd.equipment_id
                LEFT JOIN MaintenanceJob mj ON mj.breakdown_id = bd.breakdown_id
                LEFT JOIN Vendor v ON v.vendor_id = mj.vendor_id
                ORDER BY downtime_days DESC, bd.breakdown_id"""),
            "summary": _rows(cur, "SELECT * FROM vw_DowntimeSummary ORDER BY total_downtime_days DESC"),
        }


def report_stock():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, "SELECT * FROM vw_LowStock ORDER BY shortfall DESC, item_name")


def report_audit():
    with get_cursor(commit=False) as (_, cur):
        return _rows(cur, AUDIT_SQL + " ORDER BY slot_date, start_time, booking_id")
